These files are lilypond outputs generated from the files in lilypond-passing-tests at the point that they passed completely.
They are here to provide a comparison to the output of the parent folder whenever big changes or made to confirm
that no features have regressed or been otherwise broken by other issue fixes.
